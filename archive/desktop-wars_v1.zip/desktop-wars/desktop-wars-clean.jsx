export { default } from './src/DesktopWars.jsx';

