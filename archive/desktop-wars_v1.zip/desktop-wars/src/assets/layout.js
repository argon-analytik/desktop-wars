export const CRT_MONITOR_LAYOUT = {
  width: 976,
  height: 734,
  screen: {
    x: 87,
    y: 90,
    width: 640,
    height: 480,
  },
};
